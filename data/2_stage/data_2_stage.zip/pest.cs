pest.cs (pesticides)
NAME         INIT_DF     RECALL_DF     EXCO_DF     DR_DF     NUM
pest1           null          null        null      null       1